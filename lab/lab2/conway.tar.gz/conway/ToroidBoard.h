/* A toroid is a board that loops forever.  As soon as you go off the right 
   side of the screen, you reappear on the other side.  We can implement this
   feature by changing the get/setsquare functions only.
*/

class ToroidBoard : public MatrixBoard
{
public:
    virtual ~ToroidBoard() {};
    
    virtual Square getsquare(int i, int j)
    {
        // TODO: implement function
    }

    virtual void setsquare(int i, int j, Square s)
    {
        // TODO: implement function
    }
};
