/* This game board re-implements the iterate function so that it is more efficient
   when used on position lists.
*/

class EfficientPositionListBoard : public PositionListBoard 
{    
public:
        
    /* steps through a single round of the game then prints the new board
       see https://en.wikipedia.org/wiki/Conway's_Game_of_Life#Rules for detailed rules
    */
    void iterate()
    {
        // TODO: implement function
    }
};
