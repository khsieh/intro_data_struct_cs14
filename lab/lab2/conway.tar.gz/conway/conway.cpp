#include <vector>
#include <list>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <limits>
#include <unistd.h>

using namespace std;

#include "GameBoard.h"
#include "MatrixBoard.h"
#include "ToroidBoard.h"
#include "PositionListBoard.h"
#include "EfficientPositionListBoard.h"
#include "PositionGridBoard.h"

///////////////////////////////////////////////////////////////////////////////
// main()

int main(int argc, char** argv)
{    
    MatrixBoard g;
//     ToroidBoard g;
    
    // if no arguments, display usage info
    if (argc==1) {
        cerr<< "usage: "<< argv[0] << " filename [sleep]" << endl;
        return 0;
    }
    
    // load board
    g.loadBoard(argv[1]);
    
    int sleep=500000;
    if (argc==3) {
        stringstream ss;
        ss<<argv[2];
        ss>>sleep;
    }
    
    // game loop
    while (1) {
        cout << clearscreen;
        g.iterate();
        g.print();
        usleep(sleep);
   }
}